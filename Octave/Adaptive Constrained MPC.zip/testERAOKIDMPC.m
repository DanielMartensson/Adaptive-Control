

function retval = testERAOKIDMPC (input1, input2)
  G = tf(1, [2 2 1]);
  u = linspace(255,255,120);
  t = linspace(0,119,120);
  
  % References
  R1 = linspace(100,100,20); 
  R2 = linspace(200,200,20);
  R3 = linspace(50,50,20);
  R4 = linspace(150,150,20);
  R5 = linspace(220,220,20);
  R = [R1 R2 R3 R4 R5];
  
  % Horizons
  PredictionHorizon = 19;
  ControlHorizon = 19;
  
  % Lower and upper bound input
  lb = 0;
  ub = 255;

  for i = 1:100
    x = lsim(G, u, t); close figure % Simulate "real physical system" with no plot
    output = ERAOKIDMPC(u,x,R(i), PredictionHorizon, ControlHorizon, lb, ub); % Adaptive MPC
    
    % Move forward with the signals
    u = [u(2:end) output]; 
    t = [t(2:end) (t(end) + t(2)-t(1))];
  endfor
  close figure
  % Simulate
  lsim(G, u, t);
  hold on
  plot([101 101], [0 255], 'r', [120 120], [0 255], 'r', [121.5 121.5], [0 255], 'g', [218 218], [0 255], 'g')
  text (103, 280, "First ID data")
  text (145, 280, "Adaptive MPC reference following")
endfunction
