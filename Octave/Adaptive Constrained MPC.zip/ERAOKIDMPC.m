
function [output] = ERAOKIDMPC (u,y,r,Nc,Np,lb,ub)
  
  % Find markov parameters
  g = y*pinv(triu(toeplitz(u)));
  
  % Create hankel matricies
  H0 = hank(g, 0);
  H1 = hank(g, 1);

  
  try
    % Model finding
    [U,S,V] = svd(H0, 'econ');
    
    % Model reduction
    [Un, En, Vn] = modelReduction(U, S, V);
    
    % Model
    [A, B, C, D] = ABCD(u, g, Un, En, Vn, H1);
    
    % Compute the initial state
    x0 = initialState(A,B,C,u,y);
    
    % Control
    [output] = mpc(A, B, C, r, Np, Nc, lb, ub, x0, u);
  catch
    output = 0;
  end_try_catch
  
  
  
endfunction

% Create the hankel matrix
function [H] = hank(g, k)
  H = hankel(g)(1:length(g)/2,1+k:length(g)/2+k);
endfunction

% Model reduction
function [Un, Sn, Vn] = modelReduction(U, S, V)
  nx = rank(S); % Find the model order
  Un = U(:, 1:nx);
  Sn = S(1:nx, 1:nx);
  Vn = V(:, 1:nx);
endfunction

function [A, B, C, D] = ABCD(u, g, Un, En, Vn, H1)
  % Create scalar for Bb, Cd
  ny = size(g, 1); % Number of outputs
  nu = size(u, 1); % Number of inputs
  Ey = [eye(ny) zeros(ny,size(Un*En^(1/2),1) - size(eye(ny),1))]';
  Eu = [eye(nu) zeros(nu,size(En^(1/2)*Vn',2) - size(eye(nu),2))]';
  
  % Create matrix
  A = En^(-1/2)*Un'*H1*Vn*En^(-1/2);
  B = En^(1/2)*Vn'*Eu;
  C = Ey'*Un*En^(1/2);
  D = zeros(ny, nu);
endfunction

function [output] = mpc(A, B, C, r, Np, Nc, lb, ub, x, u)
  % Reference
  R = repmat(r, Np, 1);
  % Compute the PHI matrix now!
  PHI = PHImatrix(C, A, Np);
  % Compute the GAMMA matrix now
  GAMMA = GAMMAmatrix(C, A, B, Np, Nc);
  % Compute the tuning matrix - Set it to identity matrix
  Q = eye(size(GAMMA, 1), size(GAMMA, 1));
  % Compute H matrix
  H = GAMMA'*Q*GAMMA;
  % Create initial input signal 
  q = GAMMA'*Q*PHI*x - GAMMA'*Q*R;
  % Choose the lower bounds and upper bounds limits
  LB = repmat(lb, Nc, 1);
  UB = repmat(ub, Nc, 1);
  % Compute the first input signals!
  try
    %new_u = quadprog(H, q, [], [], [], [], LB, UB); % MATLAB
    new_u = qp([], H, q, [], [], LB, UB);
    % Find the best singals from new_u
    output = bestSignals(new_u,A,B,C,r,Np,x); % This will cause no over shoot
  catch err
    warning(err.identifier, err.message);
    output = u(end); % Use past u if QP-solver computes wrong
  end_try_catch

endfunction

% Check which u gives the best results
function [best] = bestSignals(u,A,B,C,r,Np,x)
  J = zeros(1,length(u));
  I = eye(size(A));
  for i = 1:length(u)
    x = x*0; % Initial state
    x = A^Np*x + inv(I-A)*(I-A^Np)*B*u(i); % Euler simululation - Vectorized
    J(i) = abs(r-C*x);
  endfor
  [val, index] = min(J);
  best = u(index);
endfunction

function [PHI] = PHImatrix(C, A, Np)
  
  PHI = [];
  for i = 1:(Np)
    PHI = [PHI; C*A^i];
  endfor
  
endfunction

function [GAMMA] = GAMMAmatrix(C, A, B, Np, Nc)
  PHI = [];
  GAMMA = [];
  
  for j = 1:Nc
    for i = (1-j):(Np-j)
      
      if i < 0
        PHI = [PHI; 0*C*A^i*B];
      else
        PHI = [PHI; C*A^i*B];
      endif
      
    endfor
    
    % Add to PHI
    GAMMA = [GAMMA PHI];
    % Clear F
    PHI = [];
  endfor
  
endfunction

% Initial state
function [x] = initialState(A,B,C,u,y)
  
  % Start with zero vector
  x = C'*0;
  % Correct
  for i = 1:length(u)
    x = A*x + B*u(:,i);
  endfor
  
endfunction
